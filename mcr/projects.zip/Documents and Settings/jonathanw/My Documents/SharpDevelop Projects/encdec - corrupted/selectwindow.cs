using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace encdec
{
	/// <summary>
	/// Summary description for selectwindow.
	/// </summary>
	public class selectwindow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Button EncDec;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnGenKeys;
		private System.Windows.Forms.ComboBox encAlgor;
		private System.Windows.Forms.ComboBox decAlgor;
		private System.Windows.Forms.TextBox txtIVPath;
		private System.Windows.Forms.TextBox txtKeyPath;
		private System.Windows.Forms.TextBox txtEncInput;
		private System.Windows.Forms.TextBox txtEncOutput;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnIVBrowse;
		private System.Windows.Forms.Button btnKeyBrowse;
		private System.Windows.Forms.Button btnEncInputBrowse;
		private System.Windows.Forms.Button btnEncOutputBrowse;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Button btnOutputPathBrowse;
		private System.Windows.Forms.Button btnDecInputBrowse;
		private System.Windows.Forms.Button btnKeyPathBrowse;
		private System.Windows.Forms.Button btndecIVPathBrowse;
		private System.Windows.Forms.Button btnHelp;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public selectwindow()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnGenKeys = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.encAlgor = new System.Windows.Forms.ComboBox();
			this.EncDec = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.decAlgor = new System.Windows.Forms.ComboBox();
			this.txtIVPath = new System.Windows.Forms.TextBox();
			this.txtKeyPath = new System.Windows.Forms.TextBox();
			this.txtEncInput = new System.Windows.Forms.TextBox();
			this.txtEncOutput = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.btnIVBrowse = new System.Windows.Forms.Button();
			this.btnKeyBrowse = new System.Windows.Forms.Button();
			this.btnEncInputBrowse = new System.Windows.Forms.Button();
			this.btnEncOutputBrowse = new System.Windows.Forms.Button();
			this.btnOutputPathBrowse = new System.Windows.Forms.Button();
			this.btnDecInputBrowse = new System.Windows.Forms.Button();
			this.btnKeyPathBrowse = new System.Windows.Forms.Button();
			this.btndecIVPathBrowse = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.btnHelp = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGenKeys
			// 
			this.btnGenKeys.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnGenKeys.Location = new System.Drawing.Point(184, 208);
			this.btnGenKeys.Name = "btnGenKeys";
			this.btnGenKeys.Size = new System.Drawing.Size(88, 24);
			this.btnGenKeys.TabIndex = 1;
			this.btnGenKeys.Text = "Generate Keys";
			this.btnGenKeys.Click += new System.EventHandler(this.btnGenKeys_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabPage1,
																					  this.tabPage2});
			this.tabControl1.Location = new System.Drawing.Point(8, 8);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(456, 192);
			this.tabControl1.TabIndex = 2;
			this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.btnEncOutputBrowse,
																				   this.btnEncInputBrowse,
																				   this.btnKeyBrowse,
																				   this.btnIVBrowse,
																				   this.label4,
																				   this.label3,
																				   this.label2,
																				   this.label1,
																				   this.txtEncOutput,
																				   this.txtEncInput,
																				   this.txtKeyPath,
																				   this.txtIVPath,
																				   this.encAlgor});
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(448, 166);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Encryption";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.btnOutputPathBrowse,
																				   this.btnDecInputBrowse,
																				   this.btnKeyPathBrowse,
																				   this.btndecIVPathBrowse,
																				   this.label5,
																				   this.label6,
																				   this.label7,
																				   this.label8,
																				   this.textBox1,
																				   this.textBox2,
																				   this.textBox3,
																				   this.textBox4,
																				   this.decAlgor});
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(448, 166);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Decryption";
			// 
			// encAlgor
			// 
			this.encAlgor.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.encAlgor.Items.AddRange(new object[] {
														  "TripleDES",
														  "RC2",
														  "Rijndael Managed"});
			this.encAlgor.Location = new System.Drawing.Point(8, 8);
			this.encAlgor.Name = "encAlgor";
			this.encAlgor.Size = new System.Drawing.Size(432, 21);
			this.encAlgor.TabIndex = 1;
			this.encAlgor.Text = "Select an Algorithm";
			// 
			// EncDec
			// 
			this.EncDec.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.EncDec.Location = new System.Drawing.Point(280, 208);
			this.EncDec.Name = "EncDec";
			this.EncDec.Size = new System.Drawing.Size(88, 24);
			this.EncDec.TabIndex = 4;
			this.EncDec.Text = "Encrypt";
			this.EncDec.Click += new System.EventHandler(this.EncDec_Click);
			this.EncDec.Validating += new System.ComponentModel.CancelEventHandler(this.EncDec_Validating);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnCancel.Location = new System.Drawing.Point(376, 208);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(88, 24);
			this.btnCancel.TabIndex = 5;
			this.btnCancel.Text = "Close";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// decAlgor
			// 
			this.decAlgor.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.decAlgor.Items.AddRange(new object[] {
														  "TripleDES",
														  "RC2",
														  "Rijndael Managed"});
			this.decAlgor.Location = new System.Drawing.Point(8, 8);
			this.decAlgor.Name = "decAlgor";
			this.decAlgor.Size = new System.Drawing.Size(432, 21);
			this.decAlgor.TabIndex = 2;
			this.decAlgor.Text = "Select an Algorithm";
			// 
			// txtIVPath
			// 
			this.txtIVPath.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtIVPath.Location = new System.Drawing.Point(96, 40);
			this.txtIVPath.Name = "txtIVPath";
			this.txtIVPath.Size = new System.Drawing.Size(248, 20);
			this.txtIVPath.TabIndex = 2;
			this.txtIVPath.Text = "";
			// 
			// txtKeyPath
			// 
			this.txtKeyPath.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtKeyPath.Location = new System.Drawing.Point(96, 72);
			this.txtKeyPath.Name = "txtKeyPath";
			this.txtKeyPath.Size = new System.Drawing.Size(248, 20);
			this.txtKeyPath.TabIndex = 3;
			this.txtKeyPath.Text = "";
			this.txtKeyPath.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
			// 
			// txtEncInput
			// 
			this.txtEncInput.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtEncInput.Location = new System.Drawing.Point(96, 104);
			this.txtEncInput.Name = "txtEncInput";
			this.txtEncInput.Size = new System.Drawing.Size(248, 20);
			this.txtEncInput.TabIndex = 4;
			this.txtEncInput.Text = "";
			// 
			// txtEncOutput
			// 
			this.txtEncOutput.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtEncOutput.Location = new System.Drawing.Point(96, 136);
			this.txtEncOutput.Name = "txtEncOutput";
			this.txtEncOutput.Size = new System.Drawing.Size(248, 20);
			this.txtEncOutput.TabIndex = 5;
			this.txtEncOutput.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label1.Size = new System.Drawing.Size(88, 24);
			this.label1.TabIndex = 6;
			this.label1.Text = "IV Path:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 72);
			this.label2.Name = "label2";
			this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label2.Size = new System.Drawing.Size(88, 24);
			this.label2.TabIndex = 7;
			this.label2.Text = "Key Path:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 104);
			this.label3.Name = "label3";
			this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label3.Size = new System.Drawing.Size(88, 24);
			this.label3.TabIndex = 8;
			this.label3.Text = "Input Path:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 136);
			this.label4.Name = "label4";
			this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label4.Size = new System.Drawing.Size(88, 24);
			this.label4.TabIndex = 9;
			this.label4.Text = "Output Path:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnIVBrowse
			// 
			this.btnIVBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnIVBrowse.Location = new System.Drawing.Point(352, 40);
			this.btnIVBrowse.Name = "btnIVBrowse";
			this.btnIVBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnIVBrowse.TabIndex = 10;
			this.btnIVBrowse.Text = "Browse";
			this.btnIVBrowse.Click += new System.EventHandler(this.btnIVBrowse_Click);
			// 
			// btnKeyBrowse
			// 
			this.btnKeyBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnKeyBrowse.Location = new System.Drawing.Point(352, 72);
			this.btnKeyBrowse.Name = "btnKeyBrowse";
			this.btnKeyBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnKeyBrowse.TabIndex = 11;
			this.btnKeyBrowse.Text = "Browse";
			this.btnKeyBrowse.Click += new System.EventHandler(this.btnKeyBrowse_Click);
			// 
			// btnEncInputBrowse
			// 
			this.btnEncInputBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnEncInputBrowse.Location = new System.Drawing.Point(352, 104);
			this.btnEncInputBrowse.Name = "btnEncInputBrowse";
			this.btnEncInputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnEncInputBrowse.TabIndex = 12;
			this.btnEncInputBrowse.Text = "Browse";
			this.btnEncInputBrowse.Click += new System.EventHandler(this.btnEncInputBrowse_Click);
			// 
			// btnEncOutputBrowse
			// 
			this.btnEncOutputBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnEncOutputBrowse.Location = new System.Drawing.Point(352, 136);
			this.btnEncOutputBrowse.Name = "btnEncOutputBrowse";
			this.btnEncOutputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnEncOutputBrowse.TabIndex = 13;
			this.btnEncOutputBrowse.Text = "Browse";
			this.btnEncOutputBrowse.Click += new System.EventHandler(this.btnEncOutputBrowse_Click);
			// 
			// btnOutputPathBrowse
			// 
			this.btnOutputPathBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnOutputPathBrowse.Location = new System.Drawing.Point(352, 136);
			this.btnOutputPathBrowse.Name = "btnOutputPathBrowse";
			this.btnOutputPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnOutputPathBrowse.TabIndex = 25;
			this.btnOutputPathBrowse.Text = "Browse";
			this.btnOutputPathBrowse.Click += new System.EventHandler(this.btnOutputPathBrowse_Click);
			// 
			// btnDecInputBrowse
			// 
			this.btnDecInputBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnDecInputBrowse.Location = new System.Drawing.Point(352, 104);
			this.btnDecInputBrowse.Name = "btnDecInputBrowse";
			this.btnDecInputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnDecInputBrowse.TabIndex = 24;
			this.btnDecInputBrowse.Text = "Browse";
			this.btnDecInputBrowse.Click += new System.EventHandler(this.button2_Click);
			// 
			// btnKeyPathBrowse
			// 
			this.btnKeyPathBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnKeyPathBrowse.Location = new System.Drawing.Point(352, 72);
			this.btnKeyPathBrowse.Name = "btnKeyPathBrowse";
			this.btnKeyPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnKeyPathBrowse.TabIndex = 23;
			this.btnKeyPathBrowse.Text = "Browse";
			this.btnKeyPathBrowse.Click += new System.EventHandler(this.button3_Click);
			// 
			// btndecIVPathBrowse
			// 
			this.btndecIVPathBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btndecIVPathBrowse.Location = new System.Drawing.Point(352, 40);
			this.btndecIVPathBrowse.Name = "btndecIVPathBrowse";
			this.btndecIVPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btndecIVPathBrowse.TabIndex = 22;
			this.btndecIVPathBrowse.Text = "Browse";
			this.btndecIVPathBrowse.Click += new System.EventHandler(this.button4_Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 136);
			this.label5.Name = "label5";
			this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label5.Size = new System.Drawing.Size(88, 24);
			this.label5.TabIndex = 21;
			this.label5.Text = "Output Path:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 104);
			this.label6.Name = "label6";
			this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label6.Size = new System.Drawing.Size(88, 24);
			this.label6.TabIndex = 20;
			this.label6.Text = "Input Path:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 72);
			this.label7.Name = "label7";
			this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label7.Size = new System.Drawing.Size(88, 24);
			this.label7.TabIndex = 19;
			this.label7.Text = "Key Path:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(8, 40);
			this.label8.Name = "label8";
			this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label8.Size = new System.Drawing.Size(88, 24);
			this.label8.TabIndex = 18;
			this.label8.Text = "IV Path:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBox1
			// 
			this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox1.Location = new System.Drawing.Point(96, 136);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(248, 20);
			this.textBox1.TabIndex = 17;
			this.textBox1.Text = "";
			// 
			// textBox2
			// 
			this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox2.Location = new System.Drawing.Point(96, 104);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(248, 20);
			this.textBox2.TabIndex = 16;
			this.textBox2.Text = "";
			// 
			// textBox3
			// 
			this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox3.Location = new System.Drawing.Point(96, 72);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(248, 20);
			this.textBox3.TabIndex = 15;
			this.textBox3.Text = "";
			// 
			// textBox4
			// 
			this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox4.Location = new System.Drawing.Point(96, 40);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(248, 20);
			this.textBox4.TabIndex = 14;
			this.textBox4.Text = "";
			// 
			// btnHelp
			// 
			this.btnHelp.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btnHelp.Location = new System.Drawing.Point(8, 208);
			this.btnHelp.Name = "btnHelp";
			this.btnHelp.Size = new System.Drawing.Size(88, 24);
			this.btnHelp.TabIndex = 6;
			this.btnHelp.Text = "Help";
			this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
			// 
			// selectwindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 238);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnHelp,
																		  this.btnCancel,
																		  this.EncDec,
																		  this.tabControl1,
																		  this.btnGenKeys});
			this.MaximizeBox = false;
			this.MinimumSize = new System.Drawing.Size(480, 272);
			this.Name = "selectwindow";
			this.Text = "Encryptor";
			this.Load += new System.EventHandler(this.selectwindow_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void selectwindow_Load(object sender, System.EventArgs e)
		{
		
		}

		private void textBox2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnKeyBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "Key Files (*.key)|*.key";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtKeyPath.Text = ofd.FileName;
					this.textBox3.Text = ofd.FileName;
				}
			}
		}

		private void tabControl1_TabIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl1.SelectedIndex == 0) 
			{
				this.EncDec.Text = "Encrypt";
			}
			if (tabControl1.SelectedIndex == 1) 
			{
				this.EncDec.Text = "Decrypt";
			}
		}
	
		public static void Main(string[] args) 
		{
			System.Windows.Forms.Application.Run(new encdec.selectwindow());
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void EncDec_Click(object sender, System.EventArgs e)
		{
			/*
			*/
			this.LoadKeys();
			if (this.EncDec.Text == "Decrypt") {
				//encdec.EncDec.Algorithm algor;
				switch (this.decAlgor.SelectedIndex) { 
					case 0:
						encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key, iv, encdec.EncDec.Algorithm.TDES);
						break;
					case 1:
						encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key, iv, encdec.EncDec.Algorithm.RC);
						break;
					case 2:
						encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key, iv, encdec.EncDec.Algorithm.RJ);
						break;
					default:
						encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key, iv, encdec.EncDec.Algorithm.TDES);
						break;
				}
				return;
			}
			if ( this.EncDec.Text == "Encrypt") {
				switch (this.encAlgor.SelectedIndex) { 
					case 0:
						encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key, iv, encdec.EncDec.Algorithm.TDES);
						break;
					case 1:
						encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key, iv, encdec.EncDec.Algorithm.RC);
						break;
					case 2:
						encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key, iv, encdec.EncDec.Algorithm.RJ);
						break;
					default:
						encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key, iv, encdec.EncDec.Algorithm.TDES);
						break;
				}
			}
		}

		private void btnGenKeys_Click(object sender, System.EventArgs e)
		{
			try {
				string keypath, ivpath;
				
				SaveFileDialog keysave = new SaveFileDialog();
				SaveFileDialog ivsave = new SaveFileDialog();
				
				keysave.Filter = "Key Files (*.key)|*.key";
				keysave.RestoreDirectory = true;
				
				ivsave.Filter = "IV Files (*.eiv)|*.eiv";
				ivsave.RestoreDirectory = true;
				
				if (keysave.ShowDialog() == DialogResult.OK) {
					if (ivsave.ShowDialog() == DialogResult.OK) {
						//if (!(System.IO.File.Exists(keysave.FileName) && System.IO.File.Exists(ivsave.FileName))) {
							keypath = keysave.FileName;
							ivpath = ivsave.FileName;
						//} else {
						//return;
						//}
					} else {
						return;
					}
				} else {
					return;
				}

				TripleDESCryptoServiceProvider keygener = new TripleDESCryptoServiceProvider();
				keygener.GenerateIV();
				do {
					keygener.GenerateKey();
				} while (TripleDES.IsWeakKey(keygener.Key));
				iv = keygener.IV;
				key = keygener.Key;
				this.SaveKeys(keypath, ivpath);
				/*//byte[] iv = keygener.IV;
				//byte[] key = keygener.Key;
				MessageBox.Show("key: " + key.Length + "\niv: " + iv.Length);
				FileStream keystream = System.IO.File.Open(keypath, FileMode.OpenOrCreate);
				FileStream ivstream = System.IO.File.Open(ivpath, FileMode.OpenOrCreate);
				try {
					keystream.Write(key, 0, key.Length);
					keystream.Close();
				} catch (Exception error) {
					MessageBox.Show(error.ToString(), "Error!");
				}
				try {
					ivstream.Write(iv, 0, iv.Length);
					ivstream.Close();
				} catch (Exception error) {
					MessageBox.Show(error.ToString(), "Error!");
				}
				
				this.txtKeyPath.Text = keypath;
				this.textBox4.Text = ivpath;
				this.textBox3.Text = keypath;
				this.txtIVPath.Text = ivpath;*/
			} catch (Exception blaherdljf) {
				MessageBox.Show(blaherdljf.ToString(),"Error!");
			}
		}

		private void btnIVBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "IV Files (*.eiv)|*.eiv";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtIVPath.Text = ofd.FileName;
					this.textBox4.Text = ofd.FileName;
				}
			}
		}

		private void btnEncInputBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "All File (*.*)|*";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtEncInput.Text = ofd.FileName;
				}
			}
		}

		private void btnEncOutputBrowse_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "Encrypted File (*.enc)|*.enc";
			sfd.RestoreDirectory = true;
			if (sfd.ShowDialog() == DialogResult.OK) {
				this.txtEncOutput.Text = sfd.FileName;
			}
			
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "IV Files (*.eiv)|*.eiv";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtIVPath.Text = ofd.FileName;
					this.textBox4.Text = ofd.FileName;
				}
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "Key Files (*.key)|*.key";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtKeyPath.Text = ofd.FileName;
					this.textBox3.Text = ofd.FileName;
				}
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "Encrypted File (*.enc)|*.enc";//"All File (*.*)|*";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.textBox2.Text = ofd.FileName;
				}
			}
		}

		private void btnOutputPathBrowse_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "All Files (*.*)|*";
			sfd.RestoreDirectory = true;
			if (sfd.ShowDialog() == DialogResult.OK) {
				this.textBox1.Text = sfd.FileName;
			}
			
		}

		private void EncDec_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
		
		}

		private void btnHelp_Click(object sender, System.EventArgs e)
		{
		
		}
		
		private void LoadKeys() {
			/*FileStream keyreader, ivreader;
			if (System.IO.File.Exists(this.txtIVPath.Text)) {
				keyreader = System.IO.File.Open(this.txtIVPath.Text, FileMode.Open);
			} else {
				return;
			}
			if (System.IO.File.Exists(this.txtKeyPath.Text)) {
				ivreader = System.IO.File.Open(this.txtKeyPath.Text, FileMode.Open);
			} else {
				return;
			}
			/*if (!(keyreader.Length == this.KeyLength && ivreader.Length == this.IVLength)) {
				MessageBox.Show("Bad key or iv file!", "Error!");
				return;
			}*/
			//byte[] ikey = new byte[24];
			//byte[] iiv = new byte[8];
			
			/*int blaher;
			blaher = keyreader.Read(ikey, 0, 24);
			blaher = ivreader.Read(iiv, 0, 8);*/
			// use string.Split() method
			string keyrep, ivrep;
			using (StreamReader keyreader = new StreamReader(this.txtKeyPath.Text)){
				keyrep = keyreader.ReadToEnd();
				
			}
			using (StreamReader ivreader = new StreamReader(this.txtIVPath.Text)) {
				ivrep = ivreader.ReadToEnd();
			}
			
			string[] keypeices = keyrep.Split(new char[] {' '});
			string[] ivpeices = ivrep.Split(new char[] {' '});
			
			/*foreach (string blah in keypeices) {
				
			}
			foreach (string blah in ivpeices) {
				
			}
			*/
			if (keypeices.Length != 24 || ivrep.Length != 8) {
				return;
			} 
			byte[] ikey = new byte[24];
			byte[] iiv = new byte[8];
			for (int i = 0; i < keypeices.Length; i++) {
				keypeices[i].Trim();
				ikey[i] = Convert.ToByte(keypeices[i]);
			}
			for (int i = 0; i < ivpeices.Length; i++) {
				ivpeices[i].Trim();
				iiv[i] = Convert.ToByte(ivpeices[i]);
			}
			key = ikey;
			iv = iiv;
			
		}
		
		private void SaveKeys(string keypath, string ivpath) {
			string keyrep, ivrep;
			keyrep = " ";
			ivrep = " ";
			/*if (key == null or iv == null) {
				return; // throw error maybe?
			}*/
			foreach (byte i in key) {
				keyrep += i.ToString() + " ";		
			}
			keyrep = keyrep.Trim();
			foreach (byte i in iv) {
				ivrep += i.ToString() + " ";
			}
			ivrep = ivrep.Trim();
			
			using (StreamWriter keywriter = new StreamWriter(keypath)) {
				keywriter.Write(keyrep);
			}
			using (StreamWriter ivwriter = new StreamWriter(ivpath)) {
				ivwriter.Write(ivrep);
			}//			ivwriter.Close();
			
		}
		//private const int IVLength = 8;
		//private const int KeyLength = 24;
		private byte[] key;
		private byte[] iv;
	}
}
