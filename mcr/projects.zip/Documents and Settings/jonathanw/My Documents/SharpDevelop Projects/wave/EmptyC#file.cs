// created on 11/3/2003 at 2:09 PM
using CsGL.Util;
using CsGL.OpenGL;
using CsGL;
using System.Windows.Forms;
using System.Drawing;
using System;

namespace Wave {
	class Ogre : CsGL.OpenGL.OpenGLControl {
		private float[,,] points;//
		private CsGL.OpenGL.OpenGLTexture2D tex;
		private float hold;
		private int wiggle_count;
		private float xrot, yrot, zrot;
		private bool toggle;
		public Ogre() {
			CsGL.Util.Keyboard.AddListener(new Keyboard.Hook(Keyboard_Event));
			points = new float[45,45,3];
			hold = 0.0f;
			wiggle_count = 0;
			xrot = yrot = zrot = 0.0f;
			toggle = false;
		}
		
		public void Keyboard_Event(Keyboard.Event e) {
			if (e.key == Keys.Escape) {
				Application.Exit();
			}
			if (e.key == Keys.T) {
				toggle = !toggle;
			}
		}
		
		protected override void InitGLContext() {
			this.LoadTextures();
			GL.glEnable(GL.GL_TEXTURE_2D);
			GL.glShadeModel(GL.GL_SMOOTH);
			GL.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
			GL.glClearDepth(1.0f);
			GL.glEnable(GL.GL_DEPTH_TEST);
			GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
			GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
			GL.glPolygonMode(GL.GL_BACK, GL.GL_FILL);
			GL.glPolygonMode(GL.GL_FRONT, GL.GL_LINE);
			for (int x = 0; x < 45; x++) {
				for (int y = 0; y < 45; y++) {
					points[x,y,0] = (float)(x/5.0f - 4.5f);
					points[x,y,1] = (float)(y/5.0f - 4.5f);
					points[x,y,2] = (float)Math.Sin(( (x * 8.0f) / 180.0f) * Math.PI);
				}
			}
		}
		
		protected void LoadTextures() {
			tex = new OpenGLTexture2D("Tim.bmp");
		}
		
		protected override void OnSizeChanged(EventArgs e) {
			base.OnSizeChanged(e);
			GL.glMatrixMode(GL.GL_PROJECTION);
			GL.glLoadIdentity();
			GL.gluPerspective(45.0f, (double)(this.Size.Width / this.Size.Height), 0.1f, 100.0f);	
			GL.glMatrixMode(GL.GL_MODELVIEW);
			GL.glLoadIdentity();
		}
		
		public override void glDraw() {
			float float_x, float_y, float_xb, float_yb;
			
			GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
			GL.glLoadIdentity();
			GL.glTranslatef(0.0f, 0.0f, -12.0f);
			GL.glRotatef(xrot, 1.0f, 0.0f, 0.0f);
			GL.glRotatef(yrot, 0.0f, 1.0f, 0.0f);
			GL.glRotatef(zrot, 0.0f, 0.0f, 1.0f);
			
			tex.Bind();
			
			GL.glBegin(GL.GL_QUADS);
			for (int x = 0; x < 44; x++) {
				for (int y = 0; y < 44; y++) {
					float_x = (float)(x / 44.0f);
					float_y = (float)(y / 44.0f);
					float_xb = (float)((x + 1) / 44.0f);
					float_yb = (float)((y + 1) / 44.0f);
					
					GL.glTexCoord2f(float_x, float_y);
					GL.glVertex3f(points[x, y, 0], points[x, y, 1], points[x, y, 2]);
					
					GL.glTexCoord2f(float_x, float_yb);
					GL.glVertex3f(points[x, y + 1,0], points[x, y + 1,1], points[x, y+1, 2]);
					
					GL.glTexCoord2f(float_xb, float_yb);
					GL.glVertex3f(points[x + 1, y + 1, 0], points[x + 1, y + 1, 1], points[x + 1, y + 1, 2]);
					
					GL.glTexCoord2f(float_xb, float_y);
					GL.glVertex3f(points[x + 1, y, 0], points[x + 1, y, 1], points[x + 1, y, 2]);
					
				}
			}
			GL.glEnd();
			
			if (wiggle_count == 2 && toggle) {
				for (int iy = 0; iy < 45; iy++) {
					hold = points[0,iy,2];
					for (int ix = 0; ix < 44; ix++) {
						if (iy != 22) {
							points[ix,iy,2] = points[ix + 1, iy, 2];	
						}
					}
					points[44,iy,2] = hold;
				}
				wiggle_count = 0;
			} else if (wiggle_count == 2) {
				for (int iy = 0; iy < 45; iy++) {
					hold = points[0,iy,2];
					for (int ix = 0; ix < 44; ix++) {
							points[ix,iy,2] = points[ix + 1, iy, 2];	
					}
					points[44,iy,2] = hold;
				}
				wiggle_count = 0;
			}
			wiggle_count++;
			xrot += 0.2f;
			yrot += 0.3f;
			zrot += 0.4f;
					
		}
	}
}
