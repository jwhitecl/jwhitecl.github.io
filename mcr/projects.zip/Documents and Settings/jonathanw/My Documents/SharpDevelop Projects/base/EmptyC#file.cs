// created on 11/3/2003 at 2:09 PM
using CsGL.Util;
using CsGL.OpenGL;
using CsGL;
using System.Windows.Forms;
using System.Drawing;
using System;

namespace Wave {
	class Ogre : CsGL.OpenGL.OpenGLControl {
		public Ogre() {
			CsGL.Util.Keyboard.AddListener(new Keyboard.Hook(Keyboard_Event));
			
		}
		
		public void Keyboard_Event(Keyboard.Event e) {
			
		}
		
		protected override void InitGLContext() {
			this.LoadTextures();
			GL.glEnable(GL.GL_TEXTURE_2D);
			GL.glShadeModel(GL.GL_SMOOTH);
			GL.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
			GL.glClearDepth(1.0f);
			GL.glEnable(GL.GL_DEPTH_TEST);
			GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
			GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
		}
		
		protected void LoadTextures() {
			
		}
		
		protected override void OnSizeChanged(EventArgs e) {
			base.OnSizeChanged(e);
			GL.glMatrixMode(GL.GL_PROJECTION);
			GL.glLoadIdentity();
			GL.gluPerspective(45.0f, (double)(this.Size.Width / this.Size.Height), 0.1f, 100.0f);	
			GL.glMatrixMode(GL.GL_MODELVIEW);
			GL.glLoadIdentity();
		}
		
		public override void glDraw() {
			GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
			GL.glLoadIdentity();
		}
	}
}
