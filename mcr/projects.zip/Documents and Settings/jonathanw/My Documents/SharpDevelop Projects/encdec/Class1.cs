using System;
using System.IO;
using System.Security.Cryptography;

namespace encdec
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class EncDec
	{
		public static void Encrypt(string input_file, string output_file, byte[] key, byte[] ivkey, Algorithm algor) {
			FileStream input = new FileStream(input_file, FileMode.Open, FileAccess.Read);
			FileStream output = new FileStream(output_file, FileMode.Create, FileAccess.Write);
			output.SetLength(0);

			byte[] intermediate_storage = new byte[100];
			long rdlen = 0;
			long totallen = input.Length;
			int len;
			CryptoStream cs;

			switch (algor) 
			{
				case Algorithm.TDES:
					TripleDESCryptoServiceProvider tdescsp = new TripleDESCryptoServiceProvider();
					cs = new CryptoStream(output, tdescsp.CreateEncryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				case Algorithm.RC:
					RC2CryptoServiceProvider rccsp = new RC2CryptoServiceProvider();
					cs = new CryptoStream(output, rccsp.CreateEncryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				case Algorithm.RJ:
					RijndaelManaged rij = new RijndaelManaged();
					cs = new CryptoStream(output, rij.CreateEncryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				default:
					TripleDESCryptoServiceProvider tdescsper = new TripleDESCryptoServiceProvider();
					cs = new CryptoStream(output, tdescsper.CreateEncryptor(key, ivkey), CryptoStreamMode.Write);
					break;					
			}
			

			while (rdlen < totallen) 
			{
				len = input.Read(intermediate_storage, 0, 100);
				cs.Write(intermediate_storage, 0, len);
				rdlen += len;
			}
			cs.Close();
		}
		public static void Decrypt(string input_file, string output_file, byte[] key, byte[] ivkey, Algorithm algor) 
		{
			FileStream input = new FileStream(input_file, FileMode.Open, FileAccess.Read);
			FileStream output = new FileStream(output_file, FileMode.Create, FileAccess.Write);
			output.SetLength(0);

			byte[] intermediate_storage = new byte[100];
			long rdlen = 0;
			long totallen = input.Length;
			int len;
			CryptoStream cs;

			switch (algor) 
			{
				case Algorithm.TDES:
					TripleDESCryptoServiceProvider tdescsp = new TripleDESCryptoServiceProvider();
					cs = new CryptoStream(output, tdescsp.CreateDecryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				case Algorithm.RC:
					RC2CryptoServiceProvider rccsp = new RC2CryptoServiceProvider();
					cs = new CryptoStream(output, rccsp.CreateDecryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				case Algorithm.RJ:
					RijndaelManaged rij = new RijndaelManaged();
					cs = new CryptoStream(output, rij.CreateDecryptor(key, ivkey), CryptoStreamMode.Write);
					break;
				default:
					TripleDESCryptoServiceProvider tdescsper = new TripleDESCryptoServiceProvider();
					cs = new CryptoStream(output, tdescsper.CreateDecryptor(key, ivkey), CryptoStreamMode.Write);
					break;					
			}

			while (rdlen < totallen) 
			{
				len = input.Read(intermediate_storage, 0, 100);
				cs.Write(intermediate_storage, 0, len);
				rdlen += len;
			}
			cs.Close();
		}

	}
	public enum Algorithm 
	{
		TDES,
		RC,
		RJ
	}
}
