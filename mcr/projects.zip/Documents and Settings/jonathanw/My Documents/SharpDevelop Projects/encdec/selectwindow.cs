using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace encdec
{
	/// <summary>
	/// Summary description for selectwindow.
	/// </summary>
	public class selectwindow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtEncInput;
		private System.Windows.Forms.Button btnDecInputBrowse;
		private System.Windows.Forms.Button btnHelp;
		private System.Windows.Forms.TextBox txtEncOutput;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Button btndecIVPathBrowse;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button btnKeyBrowse;
		private System.Windows.Forms.ComboBox encAlgor;
		private System.Windows.Forms.Button btnOutputPathBrowse;
		private System.Windows.Forms.Button btnGenKeys;
		private System.Windows.Forms.TextBox txtIVPath;
		private System.Windows.Forms.ComboBox decAlgor;
		private System.Windows.Forms.Button btnKeyPathBrowse;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnIVBrowse;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox txtKeyPath;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button btnEncInputBrowse;
		private System.Windows.Forms.Button btnEncOutputBrowse;
		private System.Windows.Forms.Button EncDec;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public selectwindow()
		{
			//
			// Required for Windows Form Designer support
			//
			System.Windows.Forms.Application.EnableVisualStyles();
			InitializeComponent();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.btnEncOutputBrowse = new System.Windows.Forms.Button();
			this.btnEncInputBrowse = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.txtKeyPath = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btnIVBrowse = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnKeyPathBrowse = new System.Windows.Forms.Button();
			this.decAlgor = new System.Windows.Forms.ComboBox();
			this.txtIVPath = new System.Windows.Forms.TextBox();
			this.btnGenKeys = new System.Windows.Forms.Button();
			this.btnOutputPathBrowse = new System.Windows.Forms.Button();
			this.encAlgor = new System.Windows.Forms.ComboBox();
			this.btnKeyBrowse = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btndecIVPathBrowse = new System.Windows.Forms.Button();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.txtEncOutput = new System.Windows.Forms.TextBox();
			this.btnHelp = new System.Windows.Forms.Button();
			this.btnDecInputBrowse = new System.Windows.Forms.Button();
			this.txtEncInput = new System.Windows.Forms.TextBox();
			this.tabPage2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnEncOutputBrowse
			// 
			this.btnEncOutputBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnEncOutputBrowse.Location = new System.Drawing.Point(352, 136);
			this.btnEncOutputBrowse.Name = "btnEncOutputBrowse";
			this.btnEncOutputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnEncOutputBrowse.TabIndex = 13;
			this.btnEncOutputBrowse.Text = "Browse";
			this.btnEncOutputBrowse.Click += new System.EventHandler(this.btnEncOutputBrowse_Click);
			// 
			// btnEncInputBrowse
			// 
			this.btnEncInputBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnEncInputBrowse.Location = new System.Drawing.Point(352, 104);
			this.btnEncInputBrowse.Name = "btnEncInputBrowse";
			this.btnEncInputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnEncInputBrowse.TabIndex = 12;
			this.btnEncInputBrowse.Text = "Browse";
			this.btnEncInputBrowse.Click += new System.EventHandler(this.btnEncInputBrowse_Click);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(8, 40);
			this.label8.Name = "label8";
			this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label8.Size = new System.Drawing.Size(88, 24);
			this.label8.TabIndex = 18;
			this.label8.Text = "IV Path:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtKeyPath
			// 
			this.txtKeyPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtKeyPath.Location = new System.Drawing.Point(96, 72);
			this.txtKeyPath.Name = "txtKeyPath";
			this.txtKeyPath.Size = new System.Drawing.Size(248, 20);
			this.txtKeyPath.TabIndex = 3;
			this.txtKeyPath.Text = "";
			this.txtKeyPath.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
			// 
			// textBox1
			// 
			this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBox1.Location = new System.Drawing.Point(96, 136);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(248, 20);
			this.textBox1.TabIndex = 17;
			this.textBox1.Text = "";
			// 
			// btnIVBrowse
			// 
			this.btnIVBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnIVBrowse.Location = new System.Drawing.Point(352, 40);
			this.btnIVBrowse.Name = "btnIVBrowse";
			this.btnIVBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnIVBrowse.TabIndex = 10;
			this.btnIVBrowse.Text = "Browse";
			this.btnIVBrowse.Click += new System.EventHandler(this.btnIVBrowse_Click);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 136);
			this.label4.Name = "label4";
			this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label4.Size = new System.Drawing.Size(88, 24);
			this.label4.TabIndex = 9;
			this.label4.Text = "Output Path:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 136);
			this.label5.Name = "label5";
			this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label5.Size = new System.Drawing.Size(88, 24);
			this.label5.TabIndex = 21;
			this.label5.Text = "Output Path:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(8, 104);
			this.label6.Name = "label6";
			this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label6.Size = new System.Drawing.Size(88, 24);
			this.label6.TabIndex = 20;
			this.label6.Text = "Input Path:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 72);
			this.label7.Name = "label7";
			this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label7.Size = new System.Drawing.Size(88, 24);
			this.label7.TabIndex = 19;
			this.label7.Text = "Key Path:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label1.Size = new System.Drawing.Size(88, 24);
			this.label1.TabIndex = 6;
			this.label1.Text = "IV Path:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 72);
			this.label2.Name = "label2";
			this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label2.Size = new System.Drawing.Size(88, 24);
			this.label2.TabIndex = 7;
			this.label2.Text = "Key Path:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 104);
			this.label3.Name = "label3";
			this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label3.Size = new System.Drawing.Size(88, 24);
			this.label3.TabIndex = 8;
			this.label3.Text = "Input Path:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnKeyPathBrowse
			// 
			this.btnKeyPathBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnKeyPathBrowse.Location = new System.Drawing.Point(352, 72);
			this.btnKeyPathBrowse.Name = "btnKeyPathBrowse";
			this.btnKeyPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnKeyPathBrowse.TabIndex = 23;
			this.btnKeyPathBrowse.Text = "Browse";
			this.btnKeyPathBrowse.Click += new System.EventHandler(this.button3_Click);
			// 
			// decAlgor
			// 
			this.decAlgor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.decAlgor.Items.AddRange(new object[] {
						"TripleDES",
						"RC2",
						"Rijndael Managed"});
			this.decAlgor.Location = new System.Drawing.Point(8, 8);
			this.decAlgor.Name = "decAlgor";
			this.decAlgor.Size = new System.Drawing.Size(432, 21);
			this.decAlgor.TabIndex = 2;
			this.decAlgor.Text = "Select an Algorithm";
			// 
			// txtIVPath
			// 
			this.txtIVPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtIVPath.Location = new System.Drawing.Point(96, 40);
			this.txtIVPath.Name = "txtIVPath";
			this.txtIVPath.Size = new System.Drawing.Size(248, 20);
			this.txtIVPath.TabIndex = 2;
			this.txtIVPath.Text = "";
			// 
			// btnGenKeys
			// 
			this.btnGenKeys.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnGenKeys.Location = new System.Drawing.Point(184, 208);
			this.btnGenKeys.Name = "btnGenKeys";
			this.btnGenKeys.Size = new System.Drawing.Size(88, 24);
			this.btnGenKeys.TabIndex = 1;
			this.btnGenKeys.Text = "Generate Keys";
			this.btnGenKeys.Click += new System.EventHandler(this.btnGenKeys_Click);
			//
			// EncDec
			//
			this.EncDec.Anchor =  = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.EncDec.Location = new System.Drawing.Point(350, 208);
			this.EncDec.
			// 
			// btnOutputPathBrowse
			// 
			this.btnOutputPathBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOutputPathBrowse.Location = new System.Drawing.Point(352, 136);
			this.btnOutputPathBrowse.Name = "btnOutputPathBrowse";
			this.btnOutputPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnOutputPathBrowse.TabIndex = 25;
			this.btnOutputPathBrowse.Text = "Browse";
			this.btnOutputPathBrowse.Click += new System.EventHandler(this.btnOutputPathBrowse_Click);
			// 
			// encAlgor
			// 
			this.encAlgor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.encAlgor.Items.AddRange(new object[] {
						"TripleDES",
						"RC2",
						"Rijndael Managed"});
			this.encAlgor.Location = new System.Drawing.Point(8, 8);
			this.encAlgor.Name = "encAlgor";
			this.encAlgor.Size = new System.Drawing.Size(432, 21);
			this.encAlgor.TabIndex = 1;
			this.encAlgor.Text = "Select an Algorithm";
			// 
			// btnKeyBrowse
			// 
			this.btnKeyBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnKeyBrowse.Location = new System.Drawing.Point(352, 72);
			this.btnKeyBrowse.Name = "btnKeyBrowse";
			this.btnKeyBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnKeyBrowse.TabIndex = 11;
			this.btnKeyBrowse.Text = "Browse";
			this.btnKeyBrowse.Click += new System.EventHandler(this.btnKeyBrowse_Click);
			// 
			// textBox2
			// 
			this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBox2.Location = new System.Drawing.Point(96, 104);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(248, 20);
			this.textBox2.TabIndex = 16;
			this.textBox2.Text = "";
			// 
			// textBox3
			// 
			this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBox3.Location = new System.Drawing.Point(96, 72);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(248, 20);
			this.textBox3.TabIndex = 15;
			this.textBox3.Text = "";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.btnOutputPathBrowse);
			this.tabPage2.Controls.Add(this.btnDecInputBrowse);
			this.tabPage2.Controls.Add(this.btnKeyPathBrowse);
			this.tabPage2.Controls.Add(this.btndecIVPathBrowse);
			this.tabPage2.Controls.Add(this.label5);
			this.tabPage2.Controls.Add(this.label6);
			this.tabPage2.Controls.Add(this.label7);
			this.tabPage2.Controls.Add(this.label8);
			this.tabPage2.Controls.Add(this.textBox1);
			this.tabPage2.Controls.Add(this.textBox2);
			this.tabPage2.Controls.Add(this.textBox3);
			this.tabPage2.Controls.Add(this.textBox4);
			this.tabPage2.Controls.Add(this.decAlgor);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(448, 166);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Decryption";
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.Location = new System.Drawing.Point(376, 208);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(88, 24);
			this.btnCancel.TabIndex = 5;
			this.btnCancel.Text = "Close";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btndecIVPathBrowse
			// 
			this.btndecIVPathBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btndecIVPathBrowse.Location = new System.Drawing.Point(352, 40);
			this.btndecIVPathBrowse.Name = "btndecIVPathBrowse";
			this.btndecIVPathBrowse.Size = new System.Drawing.Size(88, 24);
			this.btndecIVPathBrowse.TabIndex = 22;
			this.btndecIVPathBrowse.Text = "Browse";
			this.btndecIVPathBrowse.Click += new System.EventHandler(this.button4_Click);
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.btnEncOutputBrowse);
			this.tabPage1.Controls.Add(this.btnEncInputBrowse);
			this.tabPage1.Controls.Add(this.btnKeyBrowse);
			this.tabPage1.Controls.Add(this.btnIVBrowse);
			this.tabPage1.Controls.Add(this.label4);
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.txtEncOutput);
			this.tabPage1.Controls.Add(this.txtEncInput);
			this.tabPage1.Controls.Add(this.txtKeyPath);
			this.tabPage1.Controls.Add(this.txtIVPath);
			this.tabPage1.Controls.Add(this.encAlgor);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(448, 166);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Encryption";
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(8, 8);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(456, 192);
			this.tabControl1.TabIndex = 2;
			this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
			// 
			// textBox4
			// 
			this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBox4.Location = new System.Drawing.Point(96, 40);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(248, 20);
			this.textBox4.TabIndex = 14;
			this.textBox4.Text = "";
			// 
			// txtEncOutput
			// 
			this.txtEncOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtEncOutput.Location = new System.Drawing.Point(96, 136);
			this.txtEncOutput.Name = "txtEncOutput";
			this.txtEncOutput.Size = new System.Drawing.Size(248, 20);
			this.txtEncOutput.TabIndex = 5;
			this.txtEncOutput.Text = "";
			// 
			// btnHelp
			// 
			this.btnHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnHelp.Location = new System.Drawing.Point(8, 208);
			this.btnHelp.Name = "btnHelp";
			this.btnHelp.Size = new System.Drawing.Size(88, 24);
			this.btnHelp.TabIndex = 6;
			this.btnHelp.Text = "Help";
			this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
			// 
			// btnDecInputBrowse
			// 
			this.btnDecInputBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnDecInputBrowse.Location = new System.Drawing.Point(352, 104);
			this.btnDecInputBrowse.Name = "btnDecInputBrowse";
			this.btnDecInputBrowse.Size = new System.Drawing.Size(88, 24);
			this.btnDecInputBrowse.TabIndex = 24;
			this.btnDecInputBrowse.Text = "Browse";
			this.btnDecInputBrowse.Click += new System.EventHandler(this.button2_Click);
			// 
			// txtEncInput
			// 
			this.txtEncInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtEncInput.Location = new System.Drawing.Point(96, 104);
			this.txtEncInput.Name = "txtEncInput";
			this.txtEncInput.Size = new System.Drawing.Size(248, 20);
			this.txtEncInput.TabIndex = 4;
			this.txtEncInput.Text = "";
			// 
			// selectwindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 245);
			this.Controls.Add(this.btnHelp);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.btnGenKeys);
			this.MaximizeBox = false;
			this.MinimumSize = new System.Drawing.Size(480, 272);
			this.Name = "selectwindow";
			this.Text = "Encrypter";
			this.Load += new System.EventHandler(this.selectwindow_Load);
			this.tabPage2.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		#endregion

		private void selectwindow_Load(object sender, System.EventArgs e)
		{
		
		}

		private void textBox2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnKeyBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = this.DialogKeyFilter;
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtKeyPath.Text = ofd.FileName;
					this.textBox3.Text = ofd.FileName;
				}
			}
		}

		private void tabControl1_TabIndexChanged(object sender, System.EventArgs e)
		{
			if (tabControl1.SelectedIndex == 0) 
			{
				this.EncDec.Text = "Encrypt";
			}
			if (tabControl1.SelectedIndex == 1) 
			{
				this.EncDec.Text = "Decrypt";
			}
		}
	
		public static void Main(string[] args) 
		{
			System.Windows.Forms.Application.Run(new encdec.selectwindow());
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void EncDec_Click(object sender, System.EventArgs e)
		{
			KeyNIV key = this.LoadKeys();
			try {
				if (this.EncDec.Text == "Decrypt") {
					switch (this.decAlgor.SelectedIndex) { 
						case 0:
							encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key.Key, key.IV, encdec.Algorithm.TDES);
							break;
						case 1:
							encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key.Key, key.IV, encdec.Algorithm.RC);
							break;
						case 2:
							encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key.Key, key.IV, encdec.Algorithm.RJ);
							break;
						default:
							encdec.EncDec.Decrypt(this.textBox2.Text, this.textBox1.Text, key.Key, key.IV, encdec.Algorithm.TDES);
							break;
					}
					return;
				}
				if ( this.EncDec.Text == "Encrypt") {
					switch (this.encAlgor.SelectedIndex) { 
						case 0:
							encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key.Key, key.IV, encdec.Algorithm.TDES);
							break;
						case 1:
							encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key.Key, key.IV, encdec.Algorithm.RC);
							break;
						case 2:
							encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key.Key, key.IV, encdec.Algorithm.RJ);
							break;
						default:
							encdec.EncDec.Encrypt(this.txtEncInput.Text, this.txtEncOutput.Text, key.Key, key.IV, encdec.Algorithm.TDES);
							break;
					}
					return;
				}
			} catch (System.Security.Cryptography.CryptographicException cryptoerror) {
				this.ErrorMessage(cryptoerror.ToString(), "Error!");	
			} catch (Exception error) {
				this.ErrorMessage(error.ToString(), "Error!");	
			}
		}

		private void btnGenKeys_Click(object sender, System.EventArgs e)
		{
			try {
				string keypath, ivpath;
				
				SaveFileDialog keysave = new SaveFileDialog();
				SaveFileDialog ivsave = new SaveFileDialog();
				
				keysave.Filter = this.DialogKeyFilter;
				keysave.AddExtension = true;
				keysave.RestoreDirectory = true;
				
				ivsave.Filter = this.DialogIVFilter;
				ivsave.AddExtension = true;
				ivsave.RestoreDirectory = true;
				
				if (keysave.ShowDialog() == DialogResult.OK) {
					if (ivsave.ShowDialog() == DialogResult.OK) {
							keypath = keysave.FileName;
							ivpath = ivsave.FileName;
					} else {
						return;
					}
				} else {
					return;
				}

				SymmetricAlgorithm sa = this.ServiceProvider();
				sa.GenerateIV();
				sa.GenerateKey();
				encdec.KeyNIV keys = new KeyNIV();
				keys.IV = sa.IV;
				keys.Key = sa.Key;
				this.SaveKeys(keypath, ivpath, keys);
				this.txtKeyPath.Text = keypath;
				this.textBox4.Text = ivpath;
				this.textBox3.Text = keypath;
				this.txtIVPath.Text = ivpath;
			} catch (Exception blaherdljf) {
				MessageBox.Show(blaherdljf.ToString(),"Error!");
			}
		}

		private void btnIVBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = this.DialogIVFilter;
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtIVPath.Text = ofd.FileName;
					this.textBox4.Text = ofd.FileName;
				}
			}
		}

		private void btnEncInputBrowse_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "All File (*.*)|*";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtEncInput.Text = ofd.FileName;
				}
			}
		}

		private void btnEncOutputBrowse_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "Encrypted File (*.enc)|*.enc";
			sfd.RestoreDirectory = true;
			if (sfd.ShowDialog() == DialogResult.OK) {
				this.txtEncOutput.Text = sfd.FileName;
			}
			
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = this.DialogIVFilter;
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtIVPath.Text = ofd.FileName;
					this.textBox4.Text = ofd.FileName;
				}
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = this.DialogKeyFilter; 
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.txtKeyPath.Text = ofd.FileName;
					this.textBox3.Text = ofd.FileName;
				}
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "Encrypted File (*.enc)|*.enc";
			ofd.RestoreDirectory = true;
			if (ofd.ShowDialog() == DialogResult.OK) {
				if (System.IO.File.Exists(ofd.FileName)) {
					this.textBox2.Text = ofd.FileName;
				}
			}
		}

		private void btnOutputPathBrowse_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "All Files (*.*)|*";
			sfd.RestoreDirectory = true;
			if (sfd.ShowDialog() == DialogResult.OK) {
				this.textBox1.Text = sfd.FileName;
			}
			
		}

		private void EncDec_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
		
		}

		private void btnHelp_Click(object sender, System.EventArgs e)
		{
			encdec.HelpForm hf = new HelpForm();
			hf.Show();
		}
		
		private encdec.KeyNIV LoadKeys() {
			string keyrep, ivrep;
			using (StreamReader keyreader = new StreamReader(this.txtKeyPath.Text)){
				keyrep = keyreader.ReadToEnd();
				
			}
			using (StreamReader ivreader = new StreamReader(this.txtIVPath.Text)) {
				ivrep = ivreader.ReadToEnd();
			}
			
			string[] keypeices = keyrep.Split(new char[] {' '});
			string[] ivpeices = ivrep.Split(new char[] {' '});
		
			byte[] ikey = this.ServiceProvider().Key;
			byte[] iiv = this.ServiceProvider().IV;
			
			for (int i = 0; i < keypeices.Length; i++) {
				keypeices[i].Trim();
				ikey[i] = Convert.ToByte(keypeices[i]);
			}
			for (int i = 0; i < ivpeices.Length; i++) {
				ivpeices[i].Trim();
				iiv[i] = Convert.ToByte(ivpeices[i]);
			}

			SymmetricAlgorithm sp = this.ServiceProvider();
			encdec.KeyNIV kiev = new KeyNIV();
			try {
				sp.Key = ikey;
				sp.IV = iiv;				
			} catch (Exception blah) {
				this.ErrorMessage(blah.ToString(), "Error");
			} finally {
				kiev.Key = sp.Key;
				kiev.IV = sp.IV;
			}
			return kiev;
		}
		
		private void SaveKeys(string keypath, string ivpath, encdec.KeyNIV keys) {
			string keyrep, ivrep;
			keyrep = " ";
			ivrep = " ";
			
			foreach (byte i in keys.Key) {
				keyrep += i.ToString() + " ";		
			}
			keyrep = keyrep.Trim();
			foreach (byte i in keys.IV) {
				ivrep += i.ToString() + " ";
			}
			ivrep = ivrep.Trim();
			
			using (StreamWriter keywriter = new StreamWriter(keypath)) {
				keywriter.Write(keyrep);
			}
			using (StreamWriter ivwriter = new StreamWriter(ivpath)) {
				ivwriter.Write(ivrep);
			}
			
		}
		private void ErrorMessage(string error_text, string error_caption) {
			MessageBox.Show(error_text, error_caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
		private SymmetricAlgorithm ServiceProvider() {
			switch (this.Algor) { 
					case Algorithm.TDES:
						return new TripleDESCryptoServiceProvider();
					case Algorithm.RC:
						return new RC2CryptoServiceProvider();
					case Algorithm.RJ:
						return new RijndaelManaged();
					default:
						return new TripleDESCryptoServiceProvider();
			}	
		}
		private encdec.Algorithm Algor {
			get {
				if (this.tabControl1.SelectedIndex == 0) {
					switch (this.encAlgor.SelectedIndex) {
						case 0:
							return encdec.Algorithm.TDES;
						case 1:
							return encdec.Algorithm.RC;
						case 2:
							return encdec.Algorithm.RJ;
						default:
							return encdec.Algorithm.TDES;
					}
				} else if (this.tabControl1.SelectedIndex == 1) {
					switch (this.decAlgor.SelectedIndex) {
						case 0:
							return encdec.Algorithm.TDES;
						case 1:
							return encdec.Algorithm.RC;
						case 2:
							return encdec.Algorithm.RJ;
						default:
							return encdec.Algorithm.TDES;
					}
				}
				return encdec.Algorithm.TDES;
			}
		}
		
		private string DialogKeyFilter {
			get {
				switch (this.Algor) {
					case Algorithm.TDES:
						return "Triple DES Keys (*.tdeskey)|*.tdeskey";
					case Algorithm.RC:
						return "RC2 Keys (*.rc2key)|*.rc2key";
					case Algorithm.RJ:
						return "Rijndael Keys (*.rijkey)|*.rijkey";
					default:
						return "Triple DES Keys (*.tdeskey)|*.tdeskey";
				}
			}
		}
		
		private string DialogIVFilter {
			get {
				switch (this.Algor) {
					case Algorithm.TDES:
						return "Triple DES initialization vectors (*.tdesiv)|*.tdesiv";
					case Algorithm.RC:
						return "RC2 initialization vectors (*.rc2iv)|*.rc2iv";
					case Algorithm.RJ:
						return "Rijndael initialization vectors (*.rijiv)|*.rijiv";
					default:
						return "Triple DES initialization vectors (*.tdesiv)|*.tdesiv";
				}
			}
		}

	}
	public struct KeyNIV {
		public byte[] Key;
		public byte[] IV;
	}
	/*public enum Algorithm {
		TDES,
		RC,
		RJ
	}*/
}
