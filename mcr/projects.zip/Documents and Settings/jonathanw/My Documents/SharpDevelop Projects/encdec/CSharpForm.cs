// created on 10/17/2003 at 1:48 PM
using System;
using System.Windows.Forms;

namespace encdec {
	public class HelpForm: System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox richTextBox;
		public HelpForm()
		{
			InitializeComponent();
			this.richTextBox.LoadFile(this.HelpPath);
		}
		
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			this.richTextBox = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// richTextBox
			// 
			this.richTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.richTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBox.Location = new System.Drawing.Point(0, 0);
			this.richTextBox.Name = "richTextBox";
			this.richTextBox.Size = new System.Drawing.Size(434, 415);
			this.richTextBox.TabIndex = 0;
			this.richTextBox.Text = "";
			// 
			// HelpForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(434, 415);
			this.Controls.Add(this.richTextBox);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "HelpForm";
			this.Text = "Help";
			this.ResumeLayout(false);
		}
		private string HelpPath = "index.html";
	}
}
