// project created on 11/3/2003 at 2:09 PM
using System;
using System.Windows.Forms;

namespace Wave 
{
	class MainForm : System.Windows.Forms.Form
	{
		
		
		private Wave.Ogre monster = new Ogre();
		bool finished = false;
		public MainForm()
		{
			InitializeComponent();
			monster.Dock = DockStyle.Fill;
			monster.Parent = this;
			Refresh();
			this.Show();
		}
		public void glDraw() {
			monster.glDraw();
		}
	
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 509);
			this.Name = "MainForm";
		}
			
		[STAThread]
		public static void Main(string[] args)
		{
			MainForm mf = new MainForm();
			while (mf.finished == false && !mf.IsDisposed) {
				//Application.Run(new MainForm());
				mf.Refresh();
				//mf.glDraw();
				Application.DoEvents();
			}
			mf.Dispose();
		}
	}			
}
