// created on 11/3/2003 at 2:09 PM
using CsGL.Util;
using CsGL.OpenGL;
using CsGL;
using System.Windows.Forms;
using System.Drawing;
using System;

namespace Wave {
	public struct Particle {
		public bool active;
		public float life, fade, r, g, b, x, y, z, xi, yi, zi, xg, yg, zg;
	}
	class Ogre : CsGL.OpenGL.OpenGLControl {
		private const int MAX_PARTICLES = 1000;
		bool rainbow = true;
		float slowdown = 2.0f;
		float xspeed, yspeed;
		float zoom = -40.0f;
		OpenGLTexture2D tex;
		uint delay, col, loop;
		Particle[] particle;
		Random rnd;
		float[,] colors = {
			{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
			{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
			{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}};

		public Ogre() {
			CsGL.Util.Keyboard.AddListener(new Keyboard.Hook(Keyboard_Event));
			particle = new Particle[MAX_PARTICLES];
			rnd = new Random();
			col = 0;
			xspeed = yspeed =1.0f;
			delay = 0;
		}
		
		public void Keyboard_Event(Keyboard.Event e) {
			if (e.key == Keys.NumPad8 && particle[0].yg < 1.5f) {
				for (int i = 0; i < MAX_PARTICLES; i++) {
					particle[i].yg += 0.01f;	
				}
			}
			if (e.key == Keys.NumPad2 && particle[0].yg > -1.5f) {
				for (int i = 0; i < MAX_PARTICLES; i++) {
					particle[i].yg -= 0.01f;	
				}
			}
			if (e.key == Keys.NumPad6 && particle[0].yg > -1.5f) {
				for (int i = 0; i < MAX_PARTICLES; i++) {
					particle[i].xg -= 0.01f;	
				}
			}
			if (e.key == Keys.NumPad4 && particle[0].yg < 1.5f) {
				for (int i = 0; i < MAX_PARTICLES; i++) {
					particle[i].xg += 0.01f;	
				}
			}
			if (e.key == Keys.Tab) {
				for (int i = 0; i < MAX_PARTICLES; i++) {
					particle[i].x = 0.0f;
					particle[i].y = 0.0f;
					particle[i].z = 0.0f;
					particle[i].xi = (float)((rnd.Next() % 50) - 26.0f) * 10.0f;
					particle[i].yi = (float)((rnd.Next() % 50) - 25.0f) * 10.0f;
					particle[i].zi = (float)((rnd.Next() % 50) - 25.0f) * 10.0f;
				}
			}//*/
			if (e.key == Keys.Add) {
				if (slowdown > 1.0f) {
					slowdown -= 0.01f;
				}
			}
			if (e.key == Keys.Subtract) {
				if (slowdown < 1.0f) {
					slowdown += 0.01f;
				}
			}
			if (e.key == Keys.PageUp) {
				zoom += 0.01f;
			}
			if (e.key == Keys.PageDown) {
				zoom -= 0.01f;
			}
			if (e.key == Keys.Return) {
				rainbow = !rainbow;
			}
			if (e.key == Keys.Space) {
				rainbow = false;
				col++;
				delay = 0;
				if (col > 11) {
					col = 0;
				}
			}
			if (e.key == Keys.R) {
				rainbow = !rainbow;
			}
			if (e.key == Keys.Up && yspeed < 200) {
				yspeed += 1.0f;
			}
			if (e.key == Keys.Down && yspeed >  -200) {
				yspeed -= 1.0f;
			}
			if (e.key == Keys.Left && xspeed > -200) {
				xspeed -= 1.0f;
			}
			if (e.key == Keys.Right && xspeed < 200) {
				xspeed += 1.0f;
			}
			delay++;
		}
		
		protected override void InitGLContext() {
			
			GL.glShadeModel(GL.GL_SMOOTH);
			GL.glEnable(GL.GL_TEXTURE_2D);
			GL.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
			GL.glClearDepth(1.0f);
			GL.glDisable(GL.GL_DEPTH_TEST);
			GL.glEnable(GL.GL_BLEND);
			GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
			GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
			GL.glHint(GL.GL_POINT_SMOOTH_HINT, GL.GL_NICEST);
			
			//tex.Bind();
			this.LoadTextures();
			for (loop = 0; loop < MAX_PARTICLES; loop++) {
				particle[loop].active = true;
				particle[loop].life = 1.0f;
				particle[loop].fade = (float)(rnd.Next() % 100.0f) / 1000.0f + 0.003f;
				particle[loop].r = colors[loop * (12 / MAX_PARTICLES), 0];
				particle[loop].g = colors[loop * (12 / MAX_PARTICLES), 1];
				particle[loop].b = colors[loop * (12 / MAX_PARTICLES), 2];
				particle[loop].xi = ((rnd.Next() % 50) - 26.0f) * 10.0f;
				particle[loop].yi = ((rnd.Next() % 50) - 25.0f) * 10.0f;
				particle[loop].zi = ((rnd.Next() % 50) - 25.0f) * 10.0f;
				particle[loop].xg = 0.0f;
				particle[loop].yg = -0.8f;
				particle[loop].zg = 0.0f;
			}						//*/

		}
		
		protected void LoadTextures() {
			tex = new OpenGLTexture2D("Particle.bmp");
		}
		
		protected override void OnSizeChanged(EventArgs e) {
			base.OnSizeChanged(e);
			GL.glMatrixMode(GL.GL_PROJECTION);
			GL.glLoadIdentity();
			GL.gluPerspective(45.0f, (double)(this.Size.Width / this.Size.Height), 0.1f, 200.0f);	
			GL.glMatrixMode(GL.GL_MODELVIEW);
			GL.glLoadIdentity();
		}
		
		public override void glDraw() {
			GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
			GL.glLoadIdentity();
			tex.Bind();
			for (int i = 0; i < MAX_PARTICLES; i++) {
				if (particle[i].active) {
					float x = particle[i].x;
					float y = particle[i].y;
					float z = particle[i].z + zoom;
					GL.glColor4f(particle[i].r, particle[i].g, particle[i].b, particle[i].life);
					GL.glBegin(GL.GL_TRIANGLE_STRIP);
						GL.glTexCoord2d(1,1);
						GL.glVertex3f(x + 0.5f, y + 0.5f, z);
						GL.glTexCoord2d(0, 1);
						GL.glVertex3f(x - 0.5f, y + 0.5f, z);
						GL.glTexCoord2d(1,0);
						GL.glVertex3f(x + 0.5f, y - 0.5f, z);
						GL.glTexCoord2d(0, 0);
						GL.glVertex3f(x - 0.5f, y - 0.5f, z);
					GL.glEnd();
					particle[i].x += particle[i].xi / (slowdown * 1000);
					particle[i].y += particle[i].yi / (slowdown * 1000);
					particle[i].z += particle[i].zi / (slowdown * 1000);
					particle[i].xi += particle[i].xg;
					particle[i].yi += particle[i].yg;
					particle[i].zi += particle[i].zg;
					particle[i].life -= particle[i].fade;
					if (particle[i].life < 0.0f) {
						particle[i].life = 1.0f;
						particle[i].fade = (float)(((rnd.Next() % 100) / 1000.0f) + .003f);
						particle[i].x = 0.0f;
						particle[i].y = 0.0f;
						particle[i].z = 0.0f;
						particle[i].xi = xspeed + (float)((rnd.Next() % 60) - 32.0f);
						particle[i].yi = yspeed + (float)((rnd.Next() % 60) - 30.0f);
						particle[i].zi = (float)((rnd.Next() % 60) - 30.0f);
						particle[i].r = colors[col,0];
						particle[i].g = colors[col,1];
						particle[i].b = colors[col,2];
					}
				}
				delay++;
				if (rainbow && delay > 25) {
					delay = 0;
					col++;
					if (col > 11) {
						col = 0;
					}
				}														//*/
			}
		}
	}
}
