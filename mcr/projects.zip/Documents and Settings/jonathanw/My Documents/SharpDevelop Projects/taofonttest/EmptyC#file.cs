using Tao;
using Tao.OpenGl;
using Tao.Platform.Windows;
using VectorFonts;
using System;
using System.Windows.Forms;

namespace taofonts {
	class testclass {
		//static int Width, Height;
		static uint objectlist;
		static int tex;
		public static float xrot = 0.0f;
		public static float zrot = 0.0f;
		public static float yrot = 0.0f;
		static System.Threading.Thread varmodder;
		public static void Main(string[] args) {
			try{
			Glut.glutInit();
			Glut.glutInitDisplayMode(Glut.GLUT_DOUBLE | Glut.GLUT_RGB | Glut.GLUT_DEPTH | Glut.GLUT_STENCIL);
			Glut.glutInitWindowSize(800, 600);
			Glut.glutInitWindowPosition(100, 100);
			Glut.glutCreateWindow("OBJ Loader");
			Glut.glutDisplayFunc(new Glut.DisplayCallback(Draw));
			Glut.glutKeyboardFunc(new Glut.KeyboardCallback(Keyboard));
			Glut.glutReshapeFunc(new Glut.ReshapeCallback(Resize));
			//Glut.glutSetIconTitle(null);
			Glut.glutIdleFunc(new Glut.IdleCallback(Idle));
			Init();
			varmodder = new System.Threading.Thread(new System.Threading.ThreadStart(VarConstModify));
			//varmodder.Start();
			Glut.glutMainLoop();
			}catch (Exception e) {
				MessageBox.Show(e.ToString());
			}
		}/*//*/
		private static void VarConstModify() {
			xrot += 0.3f;
			yrot += 0.2f;
			zrot += 0.125f;
			if (xrot > 360.0f) {
				xrot = 0.0f;
			}
			if (yrot > 360.0f) {
				yrot = 0.0f;
			}
			if (zrot > 360.0f) {
				zrot = 0.0f;
			}/*//*/
			System.Threading.Thread.Sleep(10);/*//*/
		}
		private static void Draw() {
			Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
			Gl.glClearDepth(1.0f);
			Gl.glLoadIdentity();
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, tex);
			//Gl.glDisable(Gl.GL_TEXTURE_2D);
			Gl.glTranslatef(0.0f, 0.0f, -25.0f);
			Gl.glRotatef((float)Math.Sin(yrot), 0.0f, 1.0f, 0.0f);
			Gl.glRotatef((float)Math.Cos(xrot), 1.0f, 0.0f, 0.0f);
			Gl.glRotatef((float)Math.Sin(zrot), 0.0f, 0.0f, 1.0f);
			
		//	Gl.glPushMatrix();
			//	
				
				
			//	Gl.glPushMatrix();
				//	Gl.glLoadIdentity();
				//	Gl.glTranslatef(0.0f, 0.0f, -5.0f);
			/*		Gl.glBegin(Gl.GL_TRIANGLES);
						Gl.glTexCoord2f(1.0f, 0.0f);
						Gl.glVertex3f(1.0f, 1.0f, 0.0f);
						Gl.glTexCoord2f(0.0f, 1.0f);
						Gl.glVertex3f(0.0f, 0.0f, 0.0f);
						Gl.glTexCoord2f(0.0f, 0.0f);
						Gl.glVertex3f(1.0f, 0.0f, 0.0f);
					Gl.glEnd();//*/
			Gl.glCallList((int)objectlist);
			Gl.glPopMatrix();
			Gl.glFlush();
			Glut.glutSwapBuffers();
			xrot += 3.0f;
			yrot += 2.0f;
			zrot += 1.25f;
/*			if (xrot > 360.0f) {
				xrot = 0.0f;
			}
			if (yrot > 360.0f) {
				yrot = 0.0f;
			}
			if (zrot > 360.0f) {
				zrot = 0.0f;
			}//*/
			GC.Collect();
		}
		private static void Resize(int w, int h) {
			Gl.glViewport(0, 0, w, h);
			Gl.glMatrixMode(Gl.GL_PROJECTION);
			Gl.glLoadIdentity();
			Glu.gluPerspective(45.0f, (float)w / (float)h, 1.0f, 300.0f);
			Gl.glMatrixMode(Gl.GL_MODELVIEW);
			Gl.glLoadIdentity();
			Glut.glutPostRedisplay();
			
		}//*/
		private static void Idle() {
			Glut.glutPostRedisplay();
			System.Threading.Thread.Sleep(1);			
		}
		private static void Init() {
			Gl.glClearDepth(1.0f);
			Gl.glMatrixMode(Gl.GL_PROJECTION);
			Gl.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
			Gl.glShadeModel(Gl.GL_SMOOTH);
			Gl.glEnable(Gl.GL_TEXTURE_2D);
			Gl.glFrontFace(Gl.GL_CCW);
			Gl.glEnable(Gl.GL_DEPTH_TEST);
			Gl.glDepthFunc(Gl.GL_LEQUAL);
			Gl.glEnable(Gl.GL_LIGHT0);
			LoadTextures();
			LoadMeshes();//*/
			
		}
		private static void LoadTextures() {
			tex = Texture.Load("Copy of bone.bmp", Gl.GL_NEAREST, Gl.GL_NEAREST);
		}
		private static void LoadMeshes() {
			OBJFileLoader mesh = new OBJFileLoader("foot.obj");
			objectlist = mesh.ListNumber;			
		}
		private static void Keyboard(byte key, int x, int y) {
			switch (key) {
				case 27:
				case (byte) 'Q':
				case (byte) 'q':
					Environment.Exit(0);
					break;
			}
			Resize(800, 600);
			Glut.glutPostRedisplay();
		}
	}
}
