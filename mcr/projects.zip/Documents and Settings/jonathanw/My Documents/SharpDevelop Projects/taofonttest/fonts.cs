/*
 * BSD Licence:
 * Copyright (c) 2003, Bryan White (bryan.white.ogl@brycom.co.nz)
 * Brycom Data Ltd, New Zealand; Brycom Data Ltd, England 
 * All rights reserved.
 * 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in the 
 * documentation and/or other materials provided with the distribution.
 * 3. Neither the name of Bryan White, Brycom Data Ltd, New Zealand, nor Brycom Data Ltd, England 
 * nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */
/*
 * This code developed over a few hours of experimentation.
 * The vfXXXX classes were cobbled together in minutes to remove proprietary classes (Point, Perimeter, Polygon)
 * These have been replaced with 'generic' classes and a converter (that will fail for you!)
 * I know it is ugly and could be improved e.g. I waste 32 indices (Oooo!), 
 * but it works and I'm in a hurry.
 * If I wanted efficient code I wouldn't have used dotNet (I'm an assembler programmer at heart,
 * but people don't want to pay for my expertise in that area anymore ...)
 * Throw away the converter, and insert your own (or use these classes as-is)
 * 
 * I use the following code to display these fonts in OpenGL; YMMV!
 * translation = location in the model
 * rotationDegrees, rotationAxis.X, rotationAxis.Y, rotationAxis.Z = how to spin it
   
            GL.glPushMatrix();
            GL.glColor3f(OGLUtil.SysColorToOpenGL(colour.R), OGLUtil.SysColorToOpenGL(colour.G), OGLUtil.SysColorToOpenGL(colour.B));
            GL.glTranslated(translation.X, translation.Y, translation.Z);
            GL.glRotated(rotationDegrees, rotationAxis.X, rotationAxis.Y, rotationAxis.Z);
            ConvertStructureToOpenGLPrimitives.Draw(structure, mVO);
            GL.glPopMatrix();
            OpenGLException.Assert();
 */
using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace VectorFonts
{
 /// <summary>
    /// static helper class to return a text string as a collection of Polygons
    /// Text is string of characters from ' ' to '~'. Others could be added
    /// A polygon is a collection of contours
    /// A contour a list of points where last point connects to first one.
    /// Note that these contours are not convex and so not suitable for OpenGL Polygon without tessellation
    /// To display as line outlines, just draw each contour as a line loop (no convex constraint needed)
    /// To display as filled, run each polygon through Tessellator (which has bugs ...)
    /// 
    /// font is fixed (IWFM!); making selectable is an exercise left for the reader!
    /// 
    /// </summary>
 public class VectorFont
 {
        /// <summary>
        /// return a text string as a collection of Polygons
        /// To display as line outlines, just draw each contour as a line loop
        /// To display as filled, run each polygon through Tesselator
        /// </summary>
        /// <param name="text"></param>
        /// <param name="fontSize"></param>
        /// <param name="xOffset"></param>
        /// <returns></returns>
        public static vfPolygon[] StringToPolys(string text, float fontSize, ref float xOffset)
        {
            if(sStdFont == null)
                InitFont();
            ArrayList polysAL = new ArrayList();
            for(int ix = 0; ix < text.Length; ++ix)
            {
                char ch  = text[ix];
                int ich = CharToIndex(ch);
                if(ich < 32 || ich > 127)
                    ch = '?';
                vfPolygon polyThisChar = CharAsPoly(ch, fontSize, ref xOffset);
                polysAL.Add(polyThisChar);
            }
            vfPolygon[] result = new vfPolygon[polysAL.Count];
            polysAL.CopyTo(result);
            return result;
        }
        #region Font engine room
        static readonly float flatteningFactor = 0.25f;   // seems to flatten to 0.25
        static readonly float sFontResolution = 32f;    // specify 'niceness' higher = nicer = more points
        static readonly float fontSizeGen = sFontResolution * flatteningFactor;
        static readonly FontFamily sFF = new FontFamily("Microsoft Sans Serif"); // hard coded but could be variable
        static GraphicsPath[] sStdFont = null;
        protected static void InitFont()
        {
            sStdFont = new GraphicsPath[128];
            StringFormat sf = new StringFormat();
            float yInvert = -sFontResolution * flatteningFactor;
            PointF pt = new PointF(0, yInvert);
            for(int ix = 32; ix < 128; ++ix)
            {
                GraphicsPath gp = new GraphicsPath();
                sStdFont[ix] = gp;
                gp.AddString(new string((char)ix, 1), sFF, 0, fontSizeGen, pt, sf);
                gp.Flatten();   // seems to flatten to 0.25
            }
        }
        public static int CharToIndex(char ch)
        {
            return (int)ch;
        }
        /// <summary>
        /// return a single character as polygon
        /// </summary>
        /// <param name="ch"></param>
        /// <param name="fontSize">emSize</param>
        /// <param name="xOffset">tally of X distance</param>
        /// <returns></returns>
        public static vfPolygon CharAsPoly(char ch, float fontSize, ref float xOffset)
        {
            float scale = fontSize / fontSizeGen;
            vfContours contours4Poly = new vfContours();
            ArrayList pts4Contour = new ArrayList();
            GraphicsPath pg = sStdFont[CharToIndex(ch)];
            PathData pd = pg.PathData;
            for(int ix = 0; ix < pd.Points.Length; ++ix)
            {
                PointF pt = new PointF(scale * pd.Points[ix].X + xOffset, -scale * pd.Points[ix].Y);
                byte ptType = pd.Types[ix];
                switch(ptType)
                {
                    // these were discovered empirically. I would like to know where the info is. BEW.
                    case 0:
                    case 1:
                        pts4Contour.Add(pt);
                        break;
                    case 129: 
                    case 161:
                        pts4Contour.Add(pt);
                        vfContour thisContour = vfContour.FromPoints(pts4Contour);
                        contours4Poly.Add(thisContour);
                        pts4Contour.Clear();
                        break;
                    default:
                        throw new Exception("PointType unknown:" + pd.Types[ix].ToString());
                }
            }
            // oops - no space for spaces // xOffset += scale * pg.GetBounds().Right;
            xOffset += scale * (Math.Max(fontSizeGen * 0.5f, pg.GetBounds().Right));

            vfPolygon result = new vfPolygon(contours4Poly);
            return result;
        }
        #endregion
 }
    public class vfPointFs : CollectionBase
    {
        public vfPointFs()
        {
        }
        public vfPointFs(PointF[] rhs)
        {
            foreach(PointF thePoint in rhs)
                Add(thePoint);
        }
        public PointF this[int index]
        {
            get { return (PointF)List[index]; }
        }
        public void Add(PointF anItem)
        {
            List.Add(anItem);
        }
    }
    public class vfContour : vfPointFs
    {
        public vfContour() : base()
        {}
        public vfContour(PointF[] rhs) : base(rhs)
        {}
        public static vfContour FromPoints(ArrayList rhs)
        {
            PointF[] thePoints = new PointF[rhs.Count];
            rhs.CopyTo(thePoints);
            return new vfContour(thePoints);
        }
    }
    public class vfContours : CollectionBase
    {
        public vfContours() : base()
        {
        }
        public vfContours(vfContour[] rhs) : base()
        {
            foreach(vfContour theContour in rhs)
                Add(theContour);
        }
        public vfContours(vfContours rhs) : base()
        {
            foreach(vfContour theContour in rhs)
                Add(theContour);
        }
        public vfContour this[int index]
        {
            get { return List[index] as vfContour; }
        }
        public void Add(vfContour anItem)
        {
            List.Add(anItem);
        }
    }
    public class vfPolygon : vfContours
    {
        public vfPolygon()
        {}
        public vfPolygon(vfContours rhs) : base(rhs)
        {}
        #region in here put your own implementation-dependant converter to your structure
        /*static public SE.SystemFrameworks.Geometry.Polygon[] AsSEGPolygons(vfPolygon[] polygons)
        {
            SE.SystemFrameworks.Geometry.Polygon[] sePolygons = new SE.SystemFrameworks.Geometry.Polygon[polygons.Length];
            for(int ix = 0; ix < polygons.Length; ++ix)
            {
                ArrayList sePerimeters = new ArrayList();
                foreach(vfContour contour in polygons[ix])
                {
                    ArrayList sePoints = new ArrayList();
                    foreach(PointF point in contour)
                    {
                        sePoints.Add(new SE.SystemFrameworks.Geometry.Point(point.X, point.Y, 0));
                    }
                    sePerimeters.Add(new SE.SystemFrameworks.Geometry.Perimeter(sePoints));
                }
                sePolygons[ix] = new SE.SystemFrameworks.Geometry.Polygon(sePerimeters);
            }
            return sePolygons;
        }//*/
        #endregion
    }
}

