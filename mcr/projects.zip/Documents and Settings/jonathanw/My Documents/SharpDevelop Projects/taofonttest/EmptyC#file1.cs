using Tao;
using Tao.OpenGl;
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace taofonts {
	public struct Vertex {
		public float x, y, z;
		public Vertex(float xi, float yi, float zi){
			x = xi;
			y = yi;
			z = zi;
		}
	}
	public struct TexVertex {
		public float x, y;
		public TexVertex(float xi, float yi) {
			x = xi;
			y = yi;
		}
	}
	public struct Polygon {
		public Vertex[] vert;
		public TexVertex[] tex;
		public float XNormal;
		public float YNormal;
		public float ZNormal;
	}
	public class OBJFileLoader {
		uint displaylist;
		public uint ListNumber{
			get{
				return displaylist;
			}
		}
		private bool FaceHasTexCoords = true;
		private int numVertexes;
		private int numTexCoords;
		private int numFaces;
		private int CurrentVertexPosition;
		private int CurrentCoordsPosition;
		private int CurrentFacePosition;
		private Vertex[] vertices;
		private TexVertex[] texcoords;
		private Polygon[] faces;
		
		
		public OBJFileLoader(string filename) {
			string[] tokens = filename.Split('.');
			FaceHasTexCoords = false;
			if (System.IO.File.Exists(filename)){
				CurrentVertexPosition = 0;
				CurrentCoordsPosition = 0;
				CurrentFacePosition = 0;
				numVertexes = 0;
				numTexCoords = 0;
				numFaces = 0;
				GetLengths(filename);
				vertices = new Vertex[numVertexes];
				texcoords = new TexVertex[numTexCoords];
				faces = new Polygon[numFaces];
				Parse(filename);
				ComputeNormals();
				MakeDisplayList();
				
			}
			
		}
		
		private void GetLengths(string filename) {
			StreamReader reader = new StreamReader(filename);
			string[] contents = (reader.ReadToEnd()).Split('\n');
			foreach (string line in contents) {
				try {
					if (line.Length > 3) {
						if (line[0] == 'v') {
							if (line[1] == ' ') {
								numVertexes += 1;
							}
							if (line[1] == 't') {
								numTexCoords += 1;
							}
						}
						if (line[0] == 'f') {
							numFaces += 1;
						}
					}
				} catch(Exception e) {
					MessageBox.Show(e.ToString());
				}
			}
			reader.Close();
		}
		
		private void Parse(string filename) {
			try {
				string intermediate;
				StreamReader reader = new StreamReader(filename);
				while (reader.Peek() != -1) {
					switch (reader.Read()) {
						case (int) 'v':
							Vertex(reader);
							break;
						case (int) 'f':
							FaceHeader(reader);
							break;
						case (int) '\n':
							break;
						default:
							intermediate = reader.ReadLine();
							break;
					}
				}
			reader.Close();
			}catch (Exception e) {
				MessageBox.Show(e.ToString());
			}
		}
		private void Vertex(StreamReader reader) {
			try{
			switch (reader.Read()){
				case ' '://vertex coords
					string[] remaining = (reader.ReadLine()).Split(' '); 
					//MessageBox.Show(remaining[0] + ' ' + remaining[1] + ' ' + remaining[2]);
					vertices[CurrentVertexPosition] = new Vertex((float)Convert.ToDouble(remaining[0]), 
					                                             (float)Convert.ToDouble(remaining[1]), 
					                                             (float)Convert.ToDouble(remaining[2]));
					CurrentVertexPosition++;
					break;
				case 't': //texture coord
					FaceHasTexCoords = true;
					string[] rem = (reader.ReadLine()).Split(' ');
					//MessageBox.Show(rem[1]);
					if (rem[0] == System.String.Empty) {
						texcoords[CurrentCoordsPosition] = new TexVertex((float)Convert.ToDouble(rem[1]),
						                                                 (float)Convert.ToDouble(rem[2]));
					} else {
						texcoords[CurrentCoordsPosition] = new TexVertex((float)Convert.ToDouble(rem[0]),
						                                                 (float)Convert.ToDouble(rem[1]));						
					}
					Application.Exit();
					CurrentCoordsPosition++;
					break;
				default:
					string dlfjkdl = reader.ReadLine();
					break;
			}
			} catch (Exception e) {
				MessageBox.Show(e.ToString());
				Application.Exit();
			}
		}
		
		private void FaceHeader(StreamReader reader) {
			try {
				if (this.FaceHasTexCoords) {
					string dorkas = reader.ReadLine();
					string[] segments = dorkas.Trim().Split(' ');
					faces[CurrentFacePosition].vert = new Vertex[3];
					faces[CurrentFacePosition].tex = new TexVertex[3];
					for (int i = 0; i < segments.Length; i++) {//foreach (string seg in segments) {//for (int i = 0; i < segments.Length; i++) {
						string[] parts = segments[i].Trim().Split('/');
						if (parts[0] == System.String.Empty) {
							int one = (int)Convert.ToDouble(parts[1]);
							int two = (int)Convert.ToDouble(parts[2]);
							faces[CurrentFacePosition].vert[i] = vertices[one - 1];
							faces[CurrentFacePosition].tex[i] = texcoords[two - 1];
						} else {
							int one = (int)Convert.ToDouble(parts[0]);
							int two = (int)Convert.ToDouble(parts[1]);/*//*/
							faces[CurrentFacePosition].vert[i] = vertices[one - 1];
							faces[CurrentFacePosition].tex[i] = texcoords[two - 1]; 
						}
						
					}
					
				} else {
					string[] segments = (reader.ReadLine()).Trim().Split(' ');
					faces[CurrentFacePosition].vert = new Vertex[segments.Length];
					for (int i = 0; i < segments.Length; i++) {
						if (segments[i] != System.String.Empty) {
							faces[CurrentFacePosition].vert[i] = vertices[(int)Convert.ToDouble(segments[i])];
						}
					}
				}//*/
				CurrentFacePosition++;
			}catch (Exception e) {
				MessageBox.Show(e.ToString() + '\n' + CurrentFacePosition + '\n' + '\n' + faces.Length + '\n');
			}
		}
		
		private void ComputeNormals() {
			int loopnum = 0;
			
				for (int i = 0; i < faces.Length; i++) {
					loopnum = i;
					try {
						//foreach(Polygon poly in faces) {
						//faces[i].XNormal = ((vertices[faces[i].VertexNum[0]].y * vertices[faces[i].VertexNum[1]].z) - (vertices[faces[i].VertexNum[0]].z * vertices[faces[i].VertexNum[1]].y));
						//faces[i].YNormal = ((vertices[faces[i].VertexNum[0]].z * vertices[faces[i].VertexNum[1]].x) - (vertices[faces[i].VertexNum[0]].x * vertices[faces[i].VertexNum[1]].z));
						//faces[i].ZNormal = ((vertices[faces[i].VertexNum[0]].x * vertices[faces[i].VertexNum[1]].y) - (vertices[faces[i].VertexNum[0]].y * vertices[faces[i].VertexNum[1]].x));
						//if (faces[i] != (Polygon)null) {
						/*//*/faces[i].XNormal = ((faces[i].vert[0].y * faces[i].vert[1].z) - (faces[i].vert[0].z * faces[i].vert[1].y));
						faces[i].YNormal = ((faces[i].vert[0].z * faces[i].vert[1].x) - (faces[i].vert[0].x * faces[i].vert[1].z));
						faces[i].ZNormal = ((faces[i].vert[0].x * faces[i].vert[1].y) - (faces[i].vert[0].y * faces[i].vert[1].x));
						
						float Magnitude = (float)Math.Sqrt(faces[i].XNormal * faces[i].XNormal + faces[i].YNormal * faces[i].YNormal + faces[i].ZNormal * faces[i].ZNormal);
						faces[i].XNormal /= Magnitude;
						faces[i].YNormal /= Magnitude;
						faces[i].ZNormal /= Magnitude;
					} catch (Exception e) {
						MessageBox.Show(e.ToString() + '\n' + loopnum);
						MessageBox.Show(faces[loopnum].vert[0].x.ToString());
						MessageBox.Show(faces[loopnum].vert[0].y.ToString());
						MessageBox.Show(faces[loopnum].vert[0].z.ToString());
					}
					//}
				}
		
			
		}
		
		private void MakeDisplayList() {
			displaylist = (uint)Gl.glGenLists(1);
			Gl.glNewList((int)displaylist, Gl.GL_COMPILE);
			Gl.glBegin(Gl.GL_TRIANGLES);
			for (int i = 0; i < faces.Length; i++) { //foreach (Polygon poly in faces){   //
				//Gl.glNormal3f(poly.XNormal, poly.YNormal, poly.ZNormal);
				Gl.glTexCoord2f(faces[i].tex[0].x, faces[i].tex[0].y);
				Gl.glVertex3f(faces[i].vert[0].x, faces[i].vert[0].y, faces[i].vert[0].z);
				
				Gl.glTexCoord2f(faces[i].tex[1].x, faces[i].tex[1].y);
				Gl.glVertex3f(faces[i].vert[1].x, faces[i].vert[1].y, faces[i].vert[1].z);
				
				Gl.glTexCoord2f(faces[i].tex[2].x, faces[i].tex[2].y);
				Gl.glVertex3f(faces[i].vert[2].x, faces[i].vert[2].y, faces[i].vert[2].z);

			} 
			Gl.glEndList();
		}
	}
	
	public class Texture {
		int[] handle = new int[1];
		public Texture(string path, uint minfilter, uint magfilter) {
			Bitmap image1 = new Bitmap(path);
			image1.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipY);
			System.Drawing.Imaging.BitmapData data1;
			Rectangle rect1 = new Rectangle(0, 0, image1.Width, image1.Height);
			data1 = image1.LockBits(rect1, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
			
			Gl.glGenTextures(1, handle);
			Bind();
			Gl.glTexParameteri((int)Gl.GL_TEXTURE_2D, (int)Gl.GL_TEXTURE_MIN_FILTER, (int)minfilter);
			Gl.glTexParameteri((int)Gl.GL_TEXTURE_2D, (int)Gl.GL_TEXTURE_MAG_FILTER, (int)magfilter);
			Gl.glTexImage2D((int)Gl.GL_TEXTURE_2D, 0, 3, image1.Width, image1.Height, 0, Gl.GL_RGB, Gl.GL_UNSIGNED_BYTE, data1.Scan0);
			
			image1.UnlockBits(data1);
			image1.Dispose();
		}
		public void Bind() {
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, handle[0]);
		}
		public static int Load(string path, uint minfilter, uint magfilter) {
			int[] handle = new int[1];
			Bitmap image1 = new Bitmap(path);
			image1.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipY);
			System.Drawing.Imaging.BitmapData data1;
			Rectangle rect1 = new Rectangle(0, 0, image1.Width, image1.Height);
			data1 = image1.LockBits(rect1, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
			
			Gl.glGenTextures(1, handle);
			Gl.glBindTexture(Gl.GL_TEXTURE_2D, handle[0]);
			Gl.glTexParameteri((int)Gl.GL_TEXTURE_2D, (int)Gl.GL_TEXTURE_MIN_FILTER, (int)minfilter);
			Gl.glTexParameteri((int)Gl.GL_TEXTURE_2D, (int)Gl.GL_TEXTURE_MAG_FILTER, (int)magfilter);
			Gl.glTexImage2D((int)Gl.GL_TEXTURE_2D, 0, 3, image1.Width, image1.Height, 0, Gl.GL_RGB, Gl.GL_UNSIGNED_BYTE, data1.Scan0);
			
			image1.UnlockBits(data1);
			image1.Dispose();
			return handle[0];
		}
	}
}
