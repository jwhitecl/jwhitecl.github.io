// created on 10/28/2003 at 1:40 PM
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using CsGL;
using CsGL.OpenGL;

namespace MyForm {
	public struct star {
		public byte r, g, b;
		public float distance, angle;
	}
	
	public class OGLControl : CsGL.OpenGL.OpenGLControl {
		
		private bool twinkle;
		private const int num_of_stars = 50;
		star[] stars;
		private float zoom = -15.0f;
		private float tilt = 90.0f;
		private float spin = 70.0f;
		private uint[] texture = new uint[1];
		private Random rnd = new Random();
		
		public OGLControl() : base() {
			this.KeyDown += new KeyEventHandler(this.KeyHandler);
			twinkle = true;
			//texture[0] = (uint)1;
		}
		
		public void KeyHandler(object sender, KeyEventArgs keyargs) {
			if (keyargs.KeyCode == Keys.Escape) {
				Application.Exit();
			}
			if (keyargs.KeyCode == Keys.T) {
				twinkle = !twinkle;
			}
			if (keyargs.KeyCode == Keys.W) {
				tilt -= 0.05f;
			}
			if (keyargs.KeyCode == Keys.S) {
				tilt -= 0.05f;
			}
			if (keyargs.KeyCode == Keys.PageUp) {
				zoom += 0.2f;
			}
			if (keyargs.KeyCode == Keys.PageDown) {
				zoom -= 0.2f; 
			}
		}
		public override void glDraw() {
			GL.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
			GL.glBindTexture(GL.GL_TEXTURE_2D, texture[0]);

			for (int i = 0; i < stars.Length; i++) {
				GL.glLoadIdentity();
				GL.glTranslatef(0.0f, 0.0f, zoom);
				GL.glRotatef(tilt, 1.0f, 0.0f, 0.0f);
				
				GL.glRotatef(stars[i].angle, 0.0f, 1.0f, 0.0f);
				GL.glTranslatef(stars[i].distance, 0.0f, 0.0f);
				
				GL.glRotatef(-stars[i].angle,0.0f,1.0f,0.0f);	// Cancel The Current Stars Angle
				GL.glRotatef(-tilt,1.0f,0.0f,0.0f);		// Cancel The Screen Tilt
				
				if (twinkle) {
					GL.glColor4ub((byte)(stars[(num_of_stars - i) - 1].r),
					              (byte)(stars[(num_of_stars - i) - 1].g),
					              (byte)(stars[(num_of_stars - i) - 1].b),
					              (byte)(255));
					GL.glBegin(GL.GL_QUADS); 
						GL.glTexCoord2f(0.0f, 0.0f);
						GL.glVertex3f(-1.0f, -1.0f, 0.0f);
						GL.glTexCoord2f(1.0f, 0.0f);
						GL.glVertex3f(1.0f, -1.0f, 0.0f);
						GL.glTexCoord2f(1.0f, 1.0f);
						GL.glVertex3f(1.0f, 1.0f, 0.0f);
						GL.glTexCoord2f(0.0f, 1.0f);
						GL.glVertex3f(-1.0f, 1.0f, 0.0f);
					GL.glEnd();
				}
				
				GL.glRotatef(spin, 0.0f, 0.0f, 1.0f);
				GL.glColor4ub((byte)stars[i].r, (byte)stars[i].g, (byte)stars[i].b, (byte)255);
				GL.glBegin(GL.GL_QUADS);
					GL.glTexCoord2f(0.0f, 0.0f); 
					GL.glVertex3f(-1.0f,-1.0f, 0.0f);
					GL.glTexCoord2f(1.0f, 0.0f); 
					GL.glVertex3f( 1.0f,-1.0f, 0.0f);
					GL.glTexCoord2f(1.0f, 1.0f); 
					GL.glVertex3f( 1.0f, 1.0f, 0.0f);
					GL.glTexCoord2f(0.0f, 1.0f); 
					GL.glVertex3f(-1.0f, 1.0f, 0.0f);
				GL.glEnd();
				spin += 0.01f;
				stars[i].angle += (float)(i / stars.Length);
				stars[i].distance -= 0.01f;
				if (stars[i].distance < 0.0f) {
					stars[i].distance += 5.0f;
					stars[i].r = (byte)(rnd.Next() % 256);
					stars[i].g = (byte)(rnd.Next() % 256);
					stars[i].b = (byte)(rnd.Next() % 256);
				}
			}
		}
		
		protected override void InitGLContext() {
			this.LoadTextures();
			GL.glEnable(GL.GL_TEXTURE_2D);
			GL.glShadeModel(GL.GL_SMOOTH);
			GL.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
			GL.glClearDepth(1.0f);
			GL.glEnable(GL.GL_DEPTH_TEST);
			GL.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
			GL.glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
			stars = new star[num_of_stars];
			for (int i = 0; i < stars.Length; i++) {
				stars[i].angle = 0.0f;
				stars[i].distance = (float)(i / stars.Length) * 5.0f;
				stars[i].r = (byte)(rnd.Next() % 256);
				stars[i].g = (byte)(rnd.Next() % 256);
				stars[i].b = (byte)(rnd.Next() % 256);
			}
		}
		
		protected override void OnSizeChanged(EventArgs e) {
			base.OnSizeChanged(e);
			GL.glMatrixMode(GL.GL_PROJECTION);
			GL.glLoadIdentity();
			GL.gluPerspective(45.0f, (double)(this.Size.Width / this.Size.Height), 0.1f, 100.0f);	
			GL.glMatrixMode(GL.GL_MODELVIEW);
			GL.glLoadIdentity();
		}
		
		private void LoadTextures() {
			Bitmap image1 = new Bitmap("star.bmp");
			image1.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipY);
			System.Drawing.Imaging.BitmapData data1;
			Rectangle rect1 = new Rectangle(0, 0, image1.Width, image1.Height);
			data1 = image1.LockBits(rect1, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
			
			GL.glGenTextures(1, texture);
			GL.glBindTexture(GL.GL_TEXTURE_2D, texture[0]);
			GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR);
			GL.glTexParameteri(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR);
			GL.glTexImage2D(GL.GL_TEXTURE_2D, 0, 3, image1.Width, image1.Height, 0, GL.GL_RGB, GL.GL_UNSIGNED_BYTE, data1.Scan0);
		}
	}
	public class CreatedForm : System.Windows.Forms.Form
	{
		private OGLControl ogre = new OGLControl();
		public CreatedForm()
		{
			InitializeComponent();
			ogre.Dock = DockStyle.Fill;
			ogre.Parent = this;
		}
		public void redraw(){
			ogre.glDraw();
			Refresh();
		}
		// THIS METHOD IS MAINTAINED BY THE FORM DESIGNER
		// DO NOT EDIT IT MANUALLY! YOUR CHANGES ARE LIKELY TO BE LOST
		void InitializeComponent() {
			// 
			// CreatedForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "CreatedForm";
		}
		public static void Main(string[] args) {
			//Application.Run(new CreatedForm());
			CreatedForm cf = new CreatedForm();
			cf.Show();
			while((CsGL.Util.Keyboard.GetKeysState())[(int)(Keys.Escape)] == false) {
				cf.redraw();
				Application.DoEvents();
			}
		}
	}
}
